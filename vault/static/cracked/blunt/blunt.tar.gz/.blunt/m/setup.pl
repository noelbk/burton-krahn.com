#!/usr/bin/perl

$host = "$ARGV[0]";
$dir = "$ARGV[1]";

if ($host eq "" || $dir eq "") { &error; }

system("echo \"set passive false\" >> .go");
system("echo \"open $host\" >> .go");
system("echo \"cd $dir\" >> .go");
system("echo \"put *.log\" >> .go");
system("echo \"go\" >> .go");
system("echo \"exit\" >> .go");

sub error {
	print "High Times\nUsage: ./setup.pl HOST DIR\n";
	exit;
}

exit;
